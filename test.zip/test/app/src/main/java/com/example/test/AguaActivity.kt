package com.example.test

/**
 * Pantalla de Termo-Regulación Sostenible.
 *
 * Permite seleccionar el estado del hogar ("Mi casa está fría" o "Mi casa está caliente")
 * y muestra consejos personalizados para mantener una temperatura confortable
 * de manera natural y ecológica.
 *
 * También ofrece una checklist de aislamiento que ayuda al usuario a identificar
 * mejoras posibles en su vivienda para conservar energía.
 */

