package com.example.test

/**
 * Pantalla de Ahorro de Electricidad.
 *
 * Contiene el "Cazador de Vampiros", una lista de aparatos que consumen energía en standby,
 * y un simulador que estima el ahorro anual si se adoptan hábitos sostenibles
 * (por ejemplo, cambiar bombillas por LED).
 *
 * También incluye una lista de consejos de eficiencia energética
 * y un botón de "Registro de Apagado" para sumar puntos ecológicos
 * cuando el usuario desconecta aparatos o apaga luces.
 */